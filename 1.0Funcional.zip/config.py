# Configurações do aplicativo

# Número máximo de usuários permitidos
# Para alterar o limite de usuários, basta mudar este número
LIMITE_USUARIOS = 2

# Email de contato para suporte
EMAIL_CONTATO = "solutivo.corp@gmail.com"

# Senha do administrador
SENHA_ADMIN = "ApagarTudo"  # Você pode mudar para uma senha mais segura
